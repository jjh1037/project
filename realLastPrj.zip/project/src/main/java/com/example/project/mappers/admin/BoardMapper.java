package com.example.project.mappers.admin;

import com.example.project.dto.admin.BoardDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface BoardMapper {
    @Select("SELECT i.*, m.memberNickName FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId ${searchQuery} ${searchQuery2} ORDER BY itemId DESC LIMIT #{startNum}, #{offset}")
    List<BoardDto> getBoardList(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId ${searchQuery} ${searchQuery2}")
    int getBoardListCount(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId ${searchQuery} ${searchQuery2}")
    int getSearchBoardListCount(String searchQuery, String searchQuery2);

    @Select("SELECT i.*, m.memberNickName FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId WHERE itemId = #{itemId}")
    BoardDto getBoardView(int itemId);

    @Delete("DELETE FROM item WHERE itemId = #{itemId}")
    void setBoardDelete(int itemId);

}
