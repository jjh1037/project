package com.example.project.mappers.admin;

import com.example.project.dto.user.MemberDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

@Mapper
public interface AdminMapper {

    @Select("SELECT * FROM member ${searchQuery} ORDER BY memberId DESC LIMIT #{startNum}, #{offset}")
    List<MemberDto> getList(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM member ${searchQuery}")
    int getListCount(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM member ${searchQuery}")
    int getSearchListCount(String searchQuery);

    @Select("SELECT COUNT(*) FROM member")
    int totalCount();

    @Update("UPDATE member SET memberEmail = #{memberEmail}, memberName = #{memberName}, memberNickName = #{memberNickName}, " +
            "memberPhone = #{memberPhone}, memberBirth = #{memberBirth}, memberAddress = #{memberAddress},memberPoint = #{memberPoint}," +
            " memberPostcode = #{memberPostcode}, memberInterest = #{memberInterest} WHERE memberId = #{memberId}")
    void setMemberUpdate(MemberDto membersDto);

    @Delete("DELETE FROM member WHERE memberId = #{memberId}")
    void setDelete(int memberId);

}
