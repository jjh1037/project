package com.example.admin_page.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/shipping")
    public String getIndex() {
        return "page/index";
    }
}
