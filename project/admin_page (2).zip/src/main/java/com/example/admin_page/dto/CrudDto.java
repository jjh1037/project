package com.example.admin_page.dto;

public class CrudDto {
    private int id; // primary key
    private int domestic; // 국내 : 1, 해외 : 0
    private String name; // 배송사 이름
    private String comNum; // 회사 전화번호
    private String telNum; // 회사 휴대전화번호
    private String address1; // 회사 사업장 주소1, ex)부산광역시 부산진구 중앙대로 668
    private String address2; // 회사 사업장 주소2, 상세주소 ex) 에이원프라자 4층
    private String city; // 회사 사업장 도시
    private String country; // 회사 사업장 나라
    private String postcode; // 회사 사업장 우편번호
    private String email; // 회사 이메일
    private String regdate; // 회원가입일자

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDomestic() {
        return domestic;
    }

    public void setDomestic(int domestic) {
        this.domestic = domestic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComNum() {
        return comNum;
    }

    public void setComNum(String comNum) {
        this.comNum = comNum;
    }

    public String getTelNum() {
        return telNum;
    }

    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegdate() {
        return regdate;
    }

    public void setRegdate(String regdate) {
        this.regdate = regdate;
    }
}
