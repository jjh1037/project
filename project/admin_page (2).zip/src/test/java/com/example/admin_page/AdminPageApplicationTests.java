package com.example.admin_page;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
