package com.example.project.service.admin.board;

import com.example.project.mappers.admin.board.BoardCarMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardCarService {

    @Autowired
    BoardCarMapper boardCarMapper;

}
