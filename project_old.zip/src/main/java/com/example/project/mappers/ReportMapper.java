package com.example.project.mappers;

import com.example.project.dto.ReportDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReportMapper {
    @Insert("INSERT INTO report VALUES(NULL,#{itemId}, #{renterId}, #{ownerId}, #{reportType}, #{reportContent}, CURRENT_TIMESTAMP)")
    public void setReport(ReportDto reportDto);
}
