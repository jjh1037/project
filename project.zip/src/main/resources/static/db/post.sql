use basicdb;

CREATE TABLE post(
post_num int not null auto_increment,
post_type varchar(8) not null,
post_title varchar(80) not null,
post_content text not null,
post_date date,
primary key(post_num)
);

CREATE TABLE category(
item_category varchar(20) not null,
primary key(item_category)
);

INSERT INTO category VALUES('자동차');
INSERT INTO category VALUES('오피스');
INSERT INTO category VALUES('해외');

CREATE TABLE member(
memberId int auto_increment,
memberEmail varchar(30) not null,
memberPasswd varchar(50) not null,
memberName varchar(12) not null,
memberRole varchar(10),
memberRegDate date,
primary key(memberId)
);

CREATE TABLE item(
itemId int auto_increment,
domestic boolean not null,
title varchar(100) not null,
name varchar(50) not null,
rentalStartDate date not null,
rentalEndDate date not null,
rentalPrice bigint not null,
address varchar(100) not null,
carrier varchar(50),
content text,
uploadDate date,
folderName varchar(10),
fileName varchar(200),
car_type varchar(20),
car_age varchar(10),
car_fuelType varchar(10),
item_category varchar(20) not null,
memberId int,
primary key(itemId),
foreign key(item_category) references category(item_category) on update cascade on delete restrict,
foreign key(memberId) references member(memberId) on update cascade on delete restrict
);

--
CREATE TABLE rentalForms(
formId int auto_increment,
domestic boolean not null,
userName varchar(20) not null,
userPhone varchar(13)not null,
rentalStartDate date not null,
rentalEndDate date not null,
postcode varchar(10),
address varchar(100),
carrier varchar(50),
userContent text,
itemId int not null,
ownerId int not null,
renterId int not null,
formStatus varchar(10) default 'saving',
createdAt timestamp,
foreign key(itemId) references item(itemId) on update cascade on delete cascade,
foreign key(ownerId) references member(memberId) on update cascade on delete restrict,
foreign key(renterId) references member(memberId) on update cascade on delete restrict,
primary key(formId)
);

CREATE TABLE checkRequest(
memberId int,
formId int,
checked boolean default false,
primary key(memberId, formId),
foreign key(memberId) references member(memberId),
foreign key(formId) references rentalForms(formId) on update cascade on delete cascade
);

CREATE TABLE message(
msgId int auto_increment,
itemId int not null,
renterId int not null,
ownerId int not null,
sentBy int not null,
msgContent text,
msgTime timestamp default current_timestamp,
primary key(msgId),
foreign key(itemId) references item(itemId) on delete cascade,
foreign key(renterId) references member(memberId) on update cascade on delete restrict,
foreign key(ownerId) references member(memberId) on update cascade on delete restrict
);

-- 장바구니 DB
CREATE TABLE cart(
cartId int auto_increment,
itemId int not null,
memberId int not null,
cartTime timestamp default current_timestamp,
primary key(cartId),
foreign key(itemId) references item(itemId) on delete cascade,
foreign key(memberId) references member(memberId) on update cascade on delete restrict
);

-- SELECT I.title, I.name, I.rentalPrice, I.rentalStartDate, I.rentalEndDate, C.cartid, C.itemid, C.memberId FROM cart AS C
-- INNER JOIN item AS I on c.itemId = I.itemId order by cartId ASC;
