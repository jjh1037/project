--When a user is not logged in, they need to be prevented from accessing the post upload function.

--Should I add more field on ItemDto when i join 2 tables