package com.example.project.service.admin;

import com.example.project.dto.admin.PageDto;
import com.example.project.dto.admin.ReportDto;
import com.example.project.mappers.admin.MemberReportMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MemberReportService {

    @Autowired
    MemberReportMapper memberReportMapper;

    public List<ReportDto> getReportSearch(int page, String searchType) {
        Map<String, Object> map = new HashMap<>();

        String searchQuery= "";
        if(searchType.equals("사기")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("금지물품")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("비매너")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("기타")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else {
            searchQuery = "";
        }

        PageDto pageDto = new PageDto();

        int startNum = (page - 1) * pageDto.getPageCount();

        map.put("searchQuery", searchQuery);
        map.put("startNum", startNum);
        map.put("offset", pageDto.getPageCount());

        return memberReportMapper.getReportList(map);
    }

    public int getReportSearchCnt(String searchType) {
        Map<String, Object> map = new HashMap<>();
        String searchQuery= "";
        if(searchType.equals("사기")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("금지물품")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("비매너")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else if(searchType.equals("기타")) {
            searchQuery = "WHERE reportType = '" + searchType + "'";
        }else {
            searchQuery = "";
        }
        map.put("searchQuery", searchQuery);

        return memberReportMapper.getReportListCount(map);
    }

    public PageDto getReportPageCalc(int page) {
        PageDto pageDto = new PageDto();

        int totalCount = memberReportMapper.getReportTotalCount();
        int totalPage = (int)Math.ceil((double)totalCount / pageDto.getPageCount());
        int startPage = ((int)(Math.ceil((double)page / pageDto.getBlockCount())) - 1 ) * pageDto.getPage() + 1;
        int endPage = startPage + pageDto.getBlockCount() - 1;

        if(endPage > totalPage) {
            endPage = totalPage;
        }

        pageDto.setPage(page);
        pageDto.setStartPage(startPage);
        pageDto.setEndPage(endPage);
        pageDto.setTotalPage(totalPage);

        return pageDto;
    }

}
