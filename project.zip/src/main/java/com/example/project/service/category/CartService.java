package com.example.project.service.category;

import com.example.project.dto.CartDto;
import com.example.project.mappers.CartMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CartService {

    @Autowired
    CartMapper cartMapper;

    public Map<String,Object> getCartList(int memberId) {
        Map<String, Object> map = new HashMap<>();

        map.put("list", cartMapper.getCart(memberId));
        map.put("cnt", cartMapper.getCartCount(memberId));

    return map;
    }

    public int getCartCount(int memberId) {
        return cartMapper.getCartCount(memberId);
    }

}
