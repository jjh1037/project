package com.example.project.service.category;

import com.example.project.dto.CartDto;
import com.example.project.mappers.CartMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CartService {

    @Autowired
    CartMapper cartMapper;

//    public Map<String,Object> getCartList(int memberId) {
//        Map<String, Object> map = new HashMap<>();
//
//        map.put("list", cartMapper.getCart(memberId));
//        map.put("cnt", cartMapper.getCartCount(memberId));
//
//    return map;
//    }

    public int getCartCount(int memberId) {
        return cartMapper.getCartCount(memberId);
    }

    public Map<String, Object> setSelDelete(List<CartDto> checkSelected) {
        Map<String, Object> map = new HashMap<>();
        for(CartDto cartDto : checkSelected) {
            cartMapper.setDelete(cartDto.getCartId());
            System.out.println(cartDto);
        }
        map.put("msg", "success");
        return map;
    }

    public Map<String, Object> setChangeToWaitingAll(List<CartDto> sendFormAll) {
        Map<String, Object> map = new HashMap<>();
        for(CartDto cartDto : sendFormAll) {
            cartMapper.setChangeFormStatusToWaiting(cartDto.getItemId(), cartDto.getMemberId());
            System.out.println(cartDto);
        }
        map.put("msg", "success");
        return map;

    }


}
