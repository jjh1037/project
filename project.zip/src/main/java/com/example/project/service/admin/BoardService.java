package com.example.project.service.admin;

import com.example.project.dto.admin.BoardDto;
import com.example.project.mappers.admin.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BoardService {
    @Autowired
    BoardMapper boardMapper;

    public List<BoardDto> getSearchBoard() {
        Map<String, Object> map = new HashMap<>();
//      무대, 자동차, 상업용가전, 오피스, 현장장비, 악기, 기타장비, 해외

//        String searchQuery= "";
//        if() {
//
//        }else {
//            searchQuery = "";
//        }
    }
}
