package com.example.project.service.admin;

import com.example.project.dto.admin.BoardDto;
import com.example.project.dto.admin.PageDto;
import com.example.project.mappers.admin.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BoardService {
    @Autowired
    BoardMapper boardMapper;
    public String getSearchQuery(String searchType, String words) {
        String searchQuery= "";
        if(!searchType.isEmpty()){
            searchQuery = "WHERE item_category = '" + searchType + "'";
        }else {
            searchQuery = "";
        }

        return searchQuery;
    }

    public List<BoardDto> getBoardSearch(int page, String searchType, String words) {
        Map<String, Object> map = new HashMap<>();
//      무대, 자동차, 상업용가전, 오피스, 현장장비, 악기, 기타장비, 해외
//        String searchQuery= "";
//        if(searchType.equals("무대")) {
//
//        }else if(searchType.equals("자동차")) {
//
//        }else if(searchType.equals("상업용가전")) {
//
//        }else if(searchType.equals("오피스")) {
//
//        }else if(searchType.equals("현장장비")) {
//
//        }else if(searchType.equals("악기")) {
//
//        }else if(searchType.equals("기타장비")) {
//
//        }else if(searchType.equals("해외")) {
//
//        }else {
//
//        }

        PageDto pageDto = new PageDto();

        int startNum = (page - 1) * pageDto.getPageCount();

        map.put("searchQuery", getSearchQuery(searchType, words));
        map.put("startNum", startNum);
        map.put("offset", pageDto.getPageCount());

        return boardMapper.getBoardList(map);

    }

    public int getBoardSearchCnt(String searchType, String words) {
        Map<String, Object> map = new HashMap<>();

        map.put("searchQuery", getSearchQuery(searchType, words));

        return boardMapper.getBoardListCount(map);
    }

    public PageDto boardPageCalc(int page,String searchType, String words) {
        PageDto pageDto = new PageDto();

        int totalCount = boardMapper.getSearchBoardListCount(getSearchQuery(searchType, words));
        int totalPage = (int)Math.ceil((double)totalCount / pageDto.getPageCount());
        int startPage = ((int)(Math.ceil((double)page / pageDto.getBlockCount())) - 1 ) * pageDto.getPage() + 1;
        int endPage = startPage + pageDto.getBlockCount() - 1;

        if(endPage > totalPage) {
            endPage = totalPage;
        }

        pageDto.setStartPage((page - 1) * pageDto.getPageCount());
        pageDto.setTotalPage(totalPage);
        pageDto.setStartPage(startPage);
        pageDto.setEndPage(endPage);
        pageDto.setPage(page);

        return pageDto;
    }
}
