package com.example.project.controller.users;

import com.example.project.dto.user.RentalFormDto;
import com.example.project.mappers.user.CategoryMapper;
import com.example.project.mappers.user.RentalFormMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SavingFormController {
    @Autowired
    CategoryMapper categoryMapper;
    @Autowired
    RentalFormMapper rentalFormMapper;
    @GetMapping("/users/member/memberInfo/cart/cartSavingFormCar")
    public String setFormSaving(@RequestParam int id, Model model) {
        model.addAttribute("list", categoryMapper.getviewItem(id));
        return "users/member/memberInfo/cart/cartSavingFormCar";
    }

    @PostMapping("/users/member/memberInfo/cart/cartSavingFormCar")
    public String setFormSaving(@ModelAttribute RentalFormDto rentalDto, Model model){
        rentalFormMapper.setCartRentalFormSaving(rentalDto);
        rentalFormMapper.setChangeCartFormWritten(rentalDto);
        rentalFormMapper.setCheckRequest(rentalDto.getOwnerId(),rentalDto.getFormId());
        return "redirect:/cart";

    }
}
