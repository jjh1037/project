package com.example.project.controller.users.categoty;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import com.example.project.mappers.MemberMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
public class MessageController {
    @Autowired
    MemberMapper memberMapper;
    //메시지 (멤버매퍼 연결)
    @PostMapping("/users/category/car/msgCar")
    public String setMessage(@ModelAttribute MessageDto msgDto, HttpSession session){

        MemberDto user = (MemberDto) session.getAttribute("user");

        msgDto.setSenderId(user.getMemberId());
        System.out.println(msgDto);
        memberMapper.setMessage(msgDto);

        return "redirect:/users/category/car/viewCar?id="+msgDto.getItemId();
    }
}
