package com.example.project.controller.users;

import com.example.project.dto.CartDto;
import com.example.project.mappers.CartMapper;
import com.example.project.mappers.CategoryMapper;
import com.example.project.service.category.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class CartController {

    @Autowired
    CartMapper cartMapper;

    @Autowired
    CartService cartService;

    @GetMapping("/cart")
    public String getCart(HttpSession session) {
        if(session.getAttribute("user")==null) {
            return "redirect:/users/member/login";
        }else {
            return "users/member/memberInfo/cart";
        }
    }

    @PostMapping("/cart")
    @ResponseBody
    public Map<String, Object> getCartList(@RequestParam int memberId) {
        Map<String, Object> map = new HashMap<>();
        List<Object> test = new ArrayList<>();
        for(CartDto cartDto : cartMapper.getCart(memberId)) {
            test.add(cartDto);
        }

        map.put("list", test); // return 값 list
        return map;
    }

    @GetMapping("/CartDuplicateCheck")
    @ResponseBody
    public Map<String, Object> setCartDuplicateCheck(@ModelAttribute CartDto cartDto) {
        Map<String, Object> map = new HashMap<>();
        if(cartMapper.getCartDuplicateCheck(cartDto) == 1) { // 중복된 값
            map.put("msg", "failure");
        } else {
            map.put("msg", "success");
        }

        return map;
    }

    @GetMapping("/addCart")
    @ResponseBody
    public Map<String, Object> setCart(@ModelAttribute CartDto cartDto){
        cartMapper.setCart(cartDto);
        return Map.of("msg","success");
    }

    @GetMapping("/deleteCart")
    public String setDeleteCart(@RequestParam int cartId) {
        cartMapper.setDelete(cartId);
        return "redirect:/cart";
    }

    @PostMapping("/deleteSelected")
    @ResponseBody
    public Map<String, Object> setDeleteSelected(@RequestBody List<CartDto> checkSelected) {
        return cartService.setSelDelete(checkSelected);
    }

    @GetMapping("/deleteAll")


    @PostMapping("/savingFormCheck")
    @ResponseBody
    public Map<String, Object> getSavingFormCheck(@RequestParam int itemId,
                                                  @RequestParam int memberId) {
        Map<String, Object> map = new HashMap<>();

        map.put("check", cartMapper.getSavingCheck(itemId, memberId)); // return 값 int
        return map;
    }

    @PostMapping("/changeToWaitingAll")
    @ResponseBody
    public Map<String, Object> setChangeToWaitingAll(@RequestBody List<CartDto> sendFormAll) {
        return cartService.setChangeToWaitingAll(sendFormAll);
    }

}
