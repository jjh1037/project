package com.example.project.controller.users;

import com.example.project.dto.CartDto;
import com.example.project.mappers.CartMapper;
import com.example.project.mappers.CategoryMapper;
import com.example.project.service.category.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
public class CartController {

    @Autowired
    CartMapper cartMapper;

    @Autowired
    CartService cartService;

    @GetMapping("/cart")
    public String getCart(HttpSession session) {
        if(session.getAttribute("user")==null) {
            return "redirect:/users/member/login";
        }else {
            return "users/member/memberInfo/cart";
        }
    }

    @PostMapping("/cart")
    @ResponseBody
    public Map<String, Object> getCartList(@RequestParam int memberId) {
        return cartService.getCartList(memberId);
    }

    @GetMapping("/addCart")
    @ResponseBody
    public Map<String, Object> setCart(@ModelAttribute CartDto cartDto){

        cartMapper.setCart(cartDto);
        return Map.of("msg","success");
    }

    @GetMapping("/deleteCart")
    public String setDeleteCart(@RequestParam int cartId) {
        cartMapper.setDelete(cartId);
        return "redirect:/cart";
    }
}
