package com.example.project.controller.users;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import com.example.project.dto.ReportDto;
import com.example.project.mappers.ReportMapper;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class reportController {

    @Autowired
    ReportMapper reportMapper;
    @PostMapping("/reportCar")
    public String setReportCar(@ModelAttribute ReportDto reportDto, HttpSession session){

        MemberDto user = (MemberDto) session.getAttribute("user");
        reportDto.setRenterId(user.getMemberId());

        reportMapper.setReport(reportDto);
        System.out.println(reportDto);

        return "redirect:/users/category/car/viewCar?id="+reportDto.getItemId();
    }
}
