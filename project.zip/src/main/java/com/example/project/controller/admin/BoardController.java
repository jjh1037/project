package com.example.project.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardController {

    @GetMapping("/admin/board")
    public String getList(Model model,
                          @RequestParam(value="searchType", defaultValue = "") String searchType,
                          @RequestParam(value="words", defaultValue = "") String words,
                          @RequestParam(value = "page", defaultValue = "1") int page) {

        model.addAttribute("cnt", shippingService.getSearchCnt(searchType, words));
        model.addAttribute("list", shippingService.getSearch(page, searchType, words));
        model.addAttribute("page", shippingService.shippingPageCalc(page));

        return "admin/board/boardList";
    }

}
