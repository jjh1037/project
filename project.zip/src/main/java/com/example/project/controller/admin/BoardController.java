package com.example.project.controller.admin;

import com.example.project.mappers.admin.BoardMapper;
import com.example.project.service.admin.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;
    @Autowired
    BoardMapper boardMapper;

    @GetMapping("/admin/boardList")
    public String getList(Model model,
                          @RequestParam(value="searchType", defaultValue = "") String searchType,
                          @RequestParam(value="words", defaultValue = "") String words,
                          @RequestParam(value = "page", defaultValue = "1") int page) {

        model.addAttribute("cnt", boardService.getBoardSearchCnt(searchType, words));
        model.addAttribute("list", boardService.getBoardSearch(page, searchType, words));
        model.addAttribute("page", boardService.boardPageCalc(page, searchType, words));

        return "admin/board/boardList";
    }

    @GetMapping("/admin/boardViewCar")
    public String getViewCar(@RequestParam int itemId, Model model) {

        model.addAttribute("view", boardMapper.getBoardView(itemId));
        return "admin/board/boardViewCar";
    }

    @GetMapping("/admin/boardView")
    public String getView(@RequestParam int itemId, Model model) {

        model.addAttribute("view", boardMapper.getBoardView(itemId));
        return "admin/board/boardView";
    }

}
