package com.example.project.controller.admin.board;

import com.example.project.mappers.admin.board.BoardCarMapper;
import com.example.project.service.admin.board.BoardCarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardCarController {

    @Autowired
    BoardCarMapper boardCarMapper;
    @Autowired
    BoardCarService boardCarService;
    @GetMapping("/boardCarList")
    public String getBoardCarList(){
        return "admin/board/boardCar/boardCarList";
    }
}
