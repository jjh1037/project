package com.example.project.mappers;

import com.example.project.dto.CartDto;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface CartMapper {
    @Insert("INSERT INTO cart VALUES(NULL, #{itemId}, #{memberId}, CURRENT_TIMESTAMP)")
    public void setCart(CartDto cartDto);

    @Select("SELECT c.cartId, c.memberId, i.folderName, i.fileName, i.item_category, i.title, i.rentalPrice, i.rentalStartDate, i.rentalEndDate FROM cart AS c INNER JOIN item AS i ON c.itemId = i.itemId  WHERE c.memberId = #{memberId} ORDER BY cartId ASC")
    List<CartDto> getCart(int memberId);

    @Select("SELECT COUNT(*) FROM cart WHERE memberId = #{memberId}")
    int getCartCount(int memberId);

    @Delete("DELETE FROM cart WHERE cartId = #{cartId}")
    void setDelete(int cartId);




//    @Select()
//    @Delete()
}
