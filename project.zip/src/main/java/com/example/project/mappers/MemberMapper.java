package com.example.project.mappers;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface MemberMapper {
    //회원가입 저장
    @Insert("INSERT INTO member VALUES(NULL, #{memberEmail},#{memberPasswd},#{memberName}, '회원', now())")
    public void setMemberInfo(MemberDto mdto);

    //로그인
    @Select("SELECT * FROM member WHERE memberEmail=#{memberEmail} AND memberPasswd=#{memberPasswd}")
    public MemberDto loginCheck(MemberDto mdto);

    //메시지
    @Insert("INSERT INTO message VALUES(NULL,#{itemId},#{senderId},#{receiverId},#{msgContent}, CURRENT_TIMESTAMP)")
    public void setMessage(MessageDto msgDto);

    @Select("SELECT \n" +
            "i.itemId, \n" +
            "i.title, \n" +
            "i.folderName, \n" +
            "i.fileName, \n" +
            "m.msgContent, \n" +
            "m.msgTime, \n" +
            "receiver.memberName\n" +
            "FROM \n" +
            "message m\n" +
            "JOIN \n" +
            "item i ON m.itemId = i.itemId\n" +
            "JOIN \n" +
            "member receiver ON m.receiverId = receiver.memberId\n" +
            "WHERE \n" +
            "m.senderId = #{memberId}\n" +
            "AND m.msgTime = (\n" +
            "SELECT MAX(m2.msgTime)\n" +
            "FROM message m2\n" +
            "WHERE m2.itemId = m.itemId AND m2.senderId = #{memberId}\n" +
            ")\n" +
            "ORDER BY \n" +
            "m.msgTime DESC;")
    public List<MessageDto> getMessageList(int memberId);

    @Delete("DELETE FROM message WHERE senderId=#{memberId} AND itemId=#{item}")
    public void setDeleteMsgs(int memberId,int item);
}
