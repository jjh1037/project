package com.example.project.mappers;

import com.example.project.dto.MemberDto;
import com.example.project.dto.MessageDto;
import com.example.project.dto.ReportDto;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface MemberMapper {
    //회원가입 저장
    @Insert("INSERT INTO member VALUES(NULL, #{memberEmail},#{memberPasswd},#{memberName}, '회원', now())")
    public void setMemberInfo(MemberDto mdto);

    //로그인
    @Select("SELECT * FROM member WHERE memberEmail=#{memberEmail} AND memberPasswd=#{memberPasswd}")
    public MemberDto loginCheck(MemberDto mdto);

    //메시지
    @Insert("INSERT INTO message VALUES(NULL,#{itemId},#{renterId},#{ownerId},#{sentBy},#{msgContent}, CURRENT_TIMESTAMP)")
    public void setMessage(MessageDto msgDto);

    @Select("SELECT \n" +
            "    i.itemId, \n" +
            "    i.title, \n" +
            "    i.fileName, \n" +
            "    i.folderName, \n" +
            "    m.memberId AS otherMemberId, \n" +
            "    m.memberName AS otherMemberName, \n" +
            "    msg.msgContent, \n" +
            "    msg.msgTime,\n" +
            "    msg.renterId, \n" +
            "    msg.ownerId \n" +
            "    FROM \n" +
            "    message msg\n" +
            "    JOIN \n" +
            "    (SELECT \n" +
            "         itemId, \n" +
            "         renterId,\n" +
            "         ownerId,\n" +
            "         MAX(msgTime) AS LatestMsgTime\n" +
            "     FROM \n" +
            "         message\n" +
            "     WHERE \n" +
            "         renterId = #{memberId} OR ownerId = #{memberId}\n" +
            "     GROUP BY \n" +
            "         itemId, renterId, ownerId) AS LatestMessages \n" +
            "ON \n" +
            "    msg.itemId = LatestMessages.itemId AND \n" +
            "    msg.renterId = LatestMessages.renterId AND\n" +
            "    msg.ownerId = LatestMessages.ownerId AND\n" +
            "    msg.msgTime = LatestMessages.LatestMsgTime\n" +
            "JOIN \n" +
            "    item i ON msg.itemId = i.itemId\n" +
            "JOIN \n" +
            "    member m ON (msg.renterId = m.memberId AND msg.renterId != #{memberId}) OR (msg.ownerId = m.memberId AND msg.ownerId != #{memberId}) ORDER BY \n" +
            "    msg.msgTime DESC;")
    public List<MessageDto> getMessageList(int memberId);

    @Delete("DELETE FROM message WHERE (renterId=#{memberId} And ownerId=#{otherMemberId} AND itemId=#{itemId}) OR(renterId=#{otherMemberId} And ownerId=#{memberId} AND itemId=#{itemId})")
    public void setDeleteMsgs(@Param("memberId") int memberId,@Param("otherMemberId") int otherMemberId,@Param("itemId") int itemId);

    // 신고
    @Select("SELECT * FROM report ${searchQuery} ORDER BY reportId DESC LIMIT #{startNum}, #{offset}")
    List<ReportDto> getReportList(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM report ${searchQuery}")
    int getReportListCount(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM report")
    int getReportTotalCount();





}
