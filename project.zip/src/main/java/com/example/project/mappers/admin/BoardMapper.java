package com.example.project.mappers.admin;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {



}
