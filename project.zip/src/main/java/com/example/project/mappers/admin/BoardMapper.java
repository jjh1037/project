package com.example.project.mappers.admin;

import com.example.project.dto.admin.BoardDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface BoardMapper {
    @Select("SELECT i.*, m.memberName FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId ${searchQuery} ORDER BY itemId DESC LIMIT #{startNum}, #{offset}")
    List<BoardDto> getBoardList(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM item ${searchQuery}")
    int getBoardListCount(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM item ${searchQuery}")
    int getSearchBoardListCount(String searchQuery);

    @Select("SELECT i.*, m.memberName FROM item AS i INNER JOIN member AS m ON i.memberId = m.memberId WHERE itemId = #{itemId}")
    BoardDto getBoardView(int itemId);

}
