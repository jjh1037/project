package com.example.project.mappers.admin.board;

import com.example.project.dto.UsersItemDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BoardCarMapper {
    @Select("SELECT * FROM item WHERE item_category='자동차' ORDER BY itemId DESC")
    public List<UsersItemDto> getBoardCarList();

    @Select("SELECT COUNT(*) FROM item WHERE item_category='자동차'")
    public int getBoardTotalCar(); //자동차리스트 total 개수
}
