package com.example.project.mappers.admin;

import com.example.project.dto.admin.ReportDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface MemberReportMapper {
    @Select("SELECT r.*, i.title FROM report AS r INNER JOIN item AS i ON r.itemId = i.itemId ${searchQuery} ORDER BY reportId DESC LIMIT #{startNum}, #{offset}")
    List<ReportDto> getReportList(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM report ${searchQuery}")
    int getReportListCount(Map<String, Object> map);

    @Select("SELECT COUNT(*) FROM report")
    int getReportTotalCount();
}
