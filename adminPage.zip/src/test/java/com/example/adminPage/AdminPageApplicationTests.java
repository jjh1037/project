package com.example.adminPage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
