package com.example.adminPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminPageApplication.class, args);
	}

}
